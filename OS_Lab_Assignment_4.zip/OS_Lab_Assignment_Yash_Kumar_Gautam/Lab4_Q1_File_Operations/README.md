# Lab4 Q1 File Operations

Python source file: `file_operations.py`

## Run
```bash
python3 file_operations.py
```

Student name: Yash Kumar Gautam
