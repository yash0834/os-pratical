# Lab4 Q2 File Allocation

Python source file: `file_allocation.py`

## Run
```bash
python3 file_allocation.py
```

Student name: Yash Kumar Gautam
