# Lab4 Q3 Directory Structures

Python source file: `access_directory.py`

## Run
```bash
python3 access_directory.py
```

Student name: Yash Kumar Gautam
