# Lab4 Q4 Free Space Access Control

Python source file: `free_space_management.py`

## Run
```bash
python3 free_space_management.py
```

Student name: Yash Kumar Gautam
