# OS Lab Assignment — Yash Kumar Gautam

This repository contains four separate Operating Systems Lab programs.

## Programs
1. Lab 4 Q1 — File Operations and Sequential Access
2. Lab 4 Q2 — Contiguous, Linked and Indexed File Allocation
3. Lab 4 Q3 — Direct Access, Indexed Access and Directory Structures
4. Lab 4 Q4 — Free-Space Management, File Deletion and Access Control

Each program is stored in its own folder with a Python source file and README.

## Requirements
- Python 3
- No third-party packages required

## Run
Open the relevant folder and execute:
```bash
python3 <filename>.py
```
