#!/usr/bin/env python3
"""Deadlock detection and recovery demonstration.
Author: Yash Kumar Gautam
Uses Allocation, Request and Available matrices.
"""
def detect_deadlock(allocation, request, available):
    processes = len(allocation)
    resources = len(available)
    work = available[:]
    finish = [all(row == 0 for row in allocation[i]) for i in range(processes)]

    while True:
        found = False
        for i in range(processes):
            if not finish[i] and all(request[i][j] <= work[j] for j in range(resources)):
                for j in range(resources):
                    work[j] += allocation[i][j]
                finish[i] = True
                found = True
        if not found:
            break
    return [i for i in range(processes) if not finish[i]]

def display(title, matrix):
    print(f"\\n{title}:")
    for i, row in enumerate(matrix):
        print(f"P{i}: {row}")

if __name__ == "__main__":
    print("DEADLOCK DETECTION AND RECOVERY")
    n = int(input("Enter number of processes: "))
    m = int(input("Enter number of resource types: "))
    allocation, request = [], []
    print("Enter Allocation matrix rows:")
    for i in range(n):
        allocation.append(list(map(int, input(f"P{i}: ").split())))
    print("Enter Request matrix rows:")
    for i in range(n):
        request.append(list(map(int, input(f"P{i}: ").split())))
    available = list(map(int, input("Enter available resources: ").split()))

    if any(len(row) != m for row in allocation + request) or len(available) != m:
        raise ValueError("Matrix rows and available vector must match resource count.")

    display("Allocation Matrix", allocation)
    display("Request Matrix", request)
    print("\\nAvailable Resources:", available)

    deadlocked = detect_deadlock(allocation, request, available)
    if not deadlocked:
        print("\\nNo deadlock detected. All processes can finish.")
    else:
        print("\\nDeadlock detected. Processes involved:", deadlocked)
        # Simple recovery demonstration: terminate one blocked process,
        # release its allocated resources, then run detection again.
        victim = deadlocked[0]
        print(f"\\nRecovery: terminating P{victim}")
        for j in range(m):
            available[j] += allocation[victim][j]
            allocation[victim][j] = 0
            request[victim][j] = 0
        print("Updated Available Resources:", available)
        remaining = detect_deadlock(allocation, request, available)
        if not remaining:
            print("Deadlock successfully recovered. All remaining processes can proceed.")
        else:
            print("Deadlock still exists among processes:", remaining)
