/* Deadlock handling: controlled deadlock scenario and prevention by ordering.
   Author: Yash Kumar Gautam
   Compile: gcc controlled_deadlock.c -o controlled_deadlock -pthread
*/
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

pthread_mutex_t resource_a = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t resource_b = PTHREAD_MUTEX_INITIALIZER;

void *controlled_demo(void *arg) {
    long id = (long)arg;
    if (id == 1) {
        pthread_mutex_lock(&resource_a);
        printf("Thread 1: holding Resource A\\n");
        usleep(100000);
        printf("Thread 1: waiting for Resource B\\n");
        pthread_mutex_lock(&resource_b);
        printf("Thread 1: acquired both resources\\n");
        pthread_mutex_unlock(&resource_b);
        pthread_mutex_unlock(&resource_a);
    } else {
        pthread_mutex_lock(&resource_b);
        printf("Thread 2: holding Resource B\\n");
        usleep(100000);
        printf("Thread 2: waiting for Resource A\\n");
        pthread_mutex_lock(&resource_a);
        printf("Thread 2: acquired both resources\\n");
        pthread_mutex_unlock(&resource_a);
        pthread_mutex_unlock(&resource_b);
    }
    return NULL;
}

void *ordered_demo(void *arg) {
    long id = (long)arg;
    /* Both threads acquire A before B: circular wait is impossible. */
    pthread_mutex_lock(&resource_a);
    printf("Thread %ld: acquired Resource A\\n", id);
    usleep(50000);
    pthread_mutex_lock(&resource_b);
    printf("Thread %ld: acquired Resource B safely\\n", id);
    pthread_mutex_unlock(&resource_b);
    pthread_mutex_unlock(&resource_a);
    return NULL;
}

int main(void) {
    pthread_t t1, t2;
    puts("--- Deadlock prevention: resource ordering A -> B ---");
    pthread_create(&t1, NULL, ordered_demo, (void *)1);
    pthread_create(&t2, NULL, ordered_demo, (void *)2);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    puts("Program completed successfully.");
    pthread_mutex_destroy(&resource_a);
    pthread_mutex_destroy(&resource_b);
    return 0;
}
