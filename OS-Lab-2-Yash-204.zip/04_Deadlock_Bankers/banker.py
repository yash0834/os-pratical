#!/usr/bin/env python3
"""Banker's Algorithm: safety check.
Author: Yash Kumar Gautam
"""
def read_matrix(name, rows, cols):
    print(f"Enter {name} matrix:")
    matrix = []
    for i in range(rows):
        values = list(map(int, input(f"P{i}: ").split()))
        if len(values) != cols:
            raise ValueError(f"Enter exactly {cols} integers.")
        matrix.append(values)
    return matrix

def display(title, matrix):
    print(f"\\n{title}:")
    for i, row in enumerate(matrix):
        print(f"P{i}: {row}")

def safety_algorithm(allocation, maximum, available):
    n, m = len(allocation), len(available)
    need = [[maximum[i][j] - allocation[i][j] for j in range(m)] for i in range(n)]
    work = available[:]
    finish = [False] * n
    safe_sequence = []

    while len(safe_sequence) < n:
        found = False
        for i in range(n):
            if not finish[i] and all(need[i][j] <= work[j] for j in range(m)):
                for j in range(m):
                    work[j] += allocation[i][j]
                safe_sequence.append(i)
                finish[i] = True
                found = True
        if not found:
            break

    display("Allocation Matrix", allocation)
    display("Maximum Matrix", maximum)
    display("Need Matrix", need)
    print("\\nAvailable Resources:", available)
    if all(finish):
        print("\\nSystem is in a SAFE state.")
        print("Safe Sequence:", " -> ".join(f"P{i}" for i in safe_sequence))
        return True
    print("\\nSystem is NOT in a safe state.")
    print("No safe sequence exists.")
    return False

if __name__ == "__main__":
    print("BANKER'S ALGORITHM")
    processes = int(input("Enter number of processes: "))
    resources = int(input("Enter number of resource types: "))
    allocation = read_matrix("Allocation", processes, resources)
    maximum = read_matrix("Maximum", processes, resources)
    available = list(map(int, input("Enter available resources: ").split()))
    if len(available) != resources:
        raise ValueError(f"Enter exactly {resources} available-resource values.")
    safety_algorithm(allocation, maximum, available)
