# Operating Systems Lab — Source Code
**Author:** Yash Kumar Gautam

## Assignment files
1. `01_Thread_Creation/thread_demo.py` — thread creation, single vs multithreaded execution, I/O-bound and CPU-bound work, race-condition demo.
2. `02_Race_Condition/race_lock_semaphore.py` — shared counter with no protection, Lock, Semaphore(1), and Semaphore(2).
3. `03_Classical_Synchronization/classical_sync.py` — Producer-Consumer, Readers-Writers, Dining Philosophers (resource ordering and waiter).
4. `04_Deadlock_Bankers/controlled_deadlock.c` — pthread resource-ordering prevention demo.
5. `04_Deadlock_Bankers/banker.py` — Banker's safety algorithm.
6. `04_Deadlock_Bankers/deadlock_detection.py` — deadlock detection and simple recovery demo.

## Run
Python files: `python3 filename.py`

C file (Linux/macOS with GCC and pthreads):
`gcc controlled_deadlock.c -o controlled_deadlock -pthread`
`./controlled_deadlock`

These are editable source-code implementations prepared from the assignment topics and the supplied code screenshots. They are not exact OCR copies of every screenshot.
