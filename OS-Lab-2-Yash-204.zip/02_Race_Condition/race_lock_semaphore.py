#!/usr/bin/env python3
"""Race Condition, Lock and Semaphore
Author: Yash Kumar Gautam
Same shared-counter workload is tested without protection, with Lock,
and with Semaphore(1). A Semaphore(2) demo limits concurrency to two.
"""
import random
import threading
import time

N_THREADS = 4
N_INCR = 20000
RUNS = 5
EXPECTED = N_THREADS * N_INCR

class Shared:
    def __init__(self):
        self.value = 0

def update(shared):
    """Read-modify-write critical section, identical for every version."""
    temp = shared.value
    if random.random() < 0.02:
        time.sleep(0)
    temp += 1
    shared.value = temp

def worker_unsafe(shared):
    for _ in range(N_INCR):
        update(shared)

def worker_lock(shared, lock):
    for _ in range(N_INCR):
        with lock:
            update(shared)

def worker_sem(shared, sem):
    for _ in range(N_INCR):
        sem.acquire()
        try:
            update(shared)
        finally:
            sem.release()

def run(factory):
    shared = Shared()
    threads = [threading.Thread(target=factory, args=(shared,))
               for _ in range(N_THREADS)]
    start = time.perf_counter()
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    return shared.value, time.perf_counter() - start

def make_unsafe(shared):
    return lambda: worker_unsafe(shared)

def make_lock(lock):
    return lambda shared: worker_lock(shared, lock)

def make_sem(sem):
    return lambda shared: worker_sem(shared, sem)

def experiment(name, factory):
    print(f"\\n--- {name} ---")
    times, correct = [], 0
    for run_no in range(1, RUNS + 1):
        actual, elapsed = run(factory)
        ok = actual == EXPECTED
        correct += ok
        times.append(elapsed)
        print(f"Run {run_no}: actual={actual}, lost={EXPECTED-actual}, "
              f"{'CORRECT' if ok else 'WRONG'}, time={elapsed:.3f}s")
    average = sum(times) / len(times)
    print(f"Correct runs: {correct}/{RUNS}; average time: {average:.3f}s")
    return correct, average

def counting_semaphore_demo():
    print("\\n--- Counting semaphore demo: Semaphore(2) ---")
    sem = threading.Semaphore(2)
    guard = threading.Lock()
    inside = 0
    peak = 0

    def task(i):
        nonlocal inside, peak
        with sem:
            with guard:
                inside += 1
                peak = max(peak, inside)
                print(f"T{i} entered (inside={inside})")
            time.sleep(0.2)
            with guard:
                inside -= 1

    threads = [threading.Thread(target=task, args=(i,)) for i in range(5)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    print(f"Peak threads inside = {peak} (limit 2)")

if __name__ == "__main__":
    print(f"Workload: {N_THREADS} threads x {N_INCR} increments, {RUNS} runs/version")
    results = {}
    results["Unprotected"] = experiment("1. UNPROTECTED (race condition)", make_unsafe)
    results["Lock"] = experiment("2. LOCK", make_lock(threading.Lock()))
    results["Semaphore(1)"] = experiment("3. SEMAPHORE(1)", make_sem(threading.Semaphore(1)))
    print("\\n--- Summary ---")
    for name, (correct, average) in results.items():
        print(f"{name:15} correct runs={correct}/{RUNS}, average={average:.3f}s")
    counting_semaphore_demo()
