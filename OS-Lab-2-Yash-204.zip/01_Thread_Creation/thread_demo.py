#!/usr/bin/env python3
"""Thread Creation, Models and Benefits
Author: Yash Kumar Gautam
Demonstrates single vs multithreaded I/O-bound and CPU-bound work,
thread IDs, join(), and a race-condition example.
"""
import threading
import time

NUM_TASKS = 4
NUM_THREADS = 4

def log(message):
    print(message, flush=True)

# Workload 1: I/O-bound (simulate waiting)
def io_task(task_id):
    tid = threading.get_ident()
    native_id = threading.get_native_id()
    log(f"[Worker-{task_id}] Thread ID={tid}, Native ID={native_id}: START")
    for progress in (20, 40, 60, 80, 100):
        time.sleep(0.2)
        log(f"[Worker-{task_id}] Progress {progress}%")
    log(f"[Worker-{task_id}] FINISH")
    return f"task-{task_id}-done"

# Workload 2: CPU-bound (count primes)
def count_primes(limit):
    count = 0
    for n in range(2, limit + 1):
        prime = True
        for divisor in range(2, int(n ** 0.5) + 1):
            if n % divisor == 0:
                prime = False
                break
        if prime:
            count += 1
    return count

def cpu_task(task_id):
    log(f"[CPU-{task_id}] START")
    result = count_primes(20000)
    log(f"[CPU-{task_id}] FINISH | primes={result}")
    return result

def run_single(tasks):
    start = time.perf_counter()
    results = [task(i) for i, task in enumerate(tasks)]
    return results, time.perf_counter() - start

def run_multi(tasks):
    results = [None] * len(tasks)
    def worker(i, task):
        results[i] = task(i)
    threads = [threading.Thread(target=worker, args=(i, task))
               for i, task in enumerate(tasks)]
    start = time.perf_counter()
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    return results, time.perf_counter() - start

# Race-condition demonstration
counter = 0
counter_lock = threading.Lock()

def increment(use_lock):
    global counter
    for _ in range(20000):
        if use_lock:
            with counter_lock:
                counter += 1
        else:
            value = counter
            time.sleep(0)  # yield to make interleaving visible
            counter = value + 1

def race_condition_demo(use_lock):
    global counter
    counter = 0
    threads = [threading.Thread(target=increment, args=(use_lock,))
               for _ in range(4)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    return counter

if __name__ == "__main__":
    print("THREAD CREATION, MODELS AND BENEFITS")
    io_tasks = [io_task] * NUM_TASKS
    print("\\n=== I/O-bound workload ===")
    _, single_time = run_single(io_tasks)
    print(f"Single-threaded time: {single_time:.2f}s")
    _, multi_time = run_multi(io_tasks)
    print(f"Multithreaded time: {multi_time:.2f}s")
    print(f"Speedup: {single_time / multi_time:.2f}x")

    print("\\n=== CPU-bound workload ===")
    cpu_tasks = [lambda i: cpu_task(i) for _ in range(NUM_TASKS)]
    _, single_cpu = run_single(cpu_tasks)
    _, multi_cpu = run_multi(cpu_tasks)
    print(f"Single-threaded time: {single_cpu:.2f}s")
    print(f"Multithreaded time: {multi_cpu:.2f}s")
    print("Python threads may show limited CPU speedup because of the GIL.")

    print("\\n=== Race condition ===")
    print("Expected value:", 4 * 20000)
    print("Without lock:", race_condition_demo(False))
    print("With lock:", race_condition_demo(True))
