#!/usr/bin/env python3
"""Classical Synchronization Problems
Author: Yash Kumar Gautam
Producer-consumer, readers-writers, and dining philosophers.
"""
import threading
import time
import random

def log(message):
    print(message, flush=True)

def run_all(threads):
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

# 1. Producer-Consumer: finite circular buffer
class CircularBuffer:
    def __init__(self, size):
        self.size = size
        self.buffer = [None] * size
        self.in_idx = 0
        self.out_idx = 0
        self.count = 0
        self.empty = threading.Semaphore(size)
        self.full = threading.Semaphore(0)
        self.mutex = threading.Lock()

    def view(self):
        return "[" + " ".join("." if x is None else str(x) for x in self.buffer) + "]"

    def put(self, item, who):
        self.empty.acquire()
        with self.mutex:
            self.buffer[self.in_idx] = item
            pos = self.in_idx
            self.in_idx = (self.in_idx + 1) % self.size
            self.count += 1
            log(f"{who} PRODUCED {item} at slot {pos} buffer={self.view()} count={self.count}")
        self.full.release()

    def get(self, who):
        self.full.acquire()
        with self.mutex:
            item = self.buffer[self.out_idx]
            self.buffer[self.out_idx] = None
            pos = self.out_idx
            self.out_idx = (self.out_idx + 1) % self.size
            self.count -= 1
            log(f"{who} CONSUMED {item} from slot {pos} buffer={self.view()} count={self.count}")
        self.empty.release()
        return item

def producer_consumer():
    print("\\n=== 1. PRODUCER-CONSUMER ===")
    n_prod, n_cons, items = 2, 2, 6
    buf = CircularBuffer(4)
    consumed = []
    result_lock = threading.Lock()

    def producer(pid):
        for k in range(1, items + 1):
            buf.put(pid * 100 + k, f"P{pid}")

    def consumer(cid):
        for _ in range(items * n_prod // n_cons):
            item = buf.get(f"C{cid}")
            with result_lock:
                consumed.append(item)
            time.sleep(random.uniform(0.01, 0.04))

    threads = [threading.Thread(target=producer, args=(i,)) for i in range(1, n_prod + 1)]
    threads += [threading.Thread(target=consumer, args=(i,)) for i in range(1, n_cons + 1)]
    run_all(threads)
    ok = len(consumed) == n_prod * items and len(set(consumed)) == len(consumed) and buf.count == 0
    print(f"Produced={n_prod*items}, consumed={len(consumed)}, buffer_count={buf.count}")
    print("CORRECT (no loss, no duplicates)" if ok else "INCORRECT")

# 2. Readers-Writers (readers preference)
def readers_writers():
    print("\\n=== 2. READERS-WRITERS ===")
    shared = {"data": 0}
    read_count = 0
    reading = 0
    rc_mutex = threading.Lock()
    rw_mutex = threading.Lock()
    violations = []

    def reader(rid):
        nonlocal read_count, reading
        for _ in range(3):
            with rc_mutex:
                read_count += 1
                if read_count == 1:
                    rw_mutex.acquire()
                reading += 1
                log(f"R{rid} ENTER active_readers={read_count}")
            value = shared["data"]
            log(f"R{rid} READS data={value}")
            time.sleep(0.02)
            with rc_mutex:
                read_count -= 1
                reading -= 1
                log(f"R{rid} EXIT active_readers={read_count}")
                if read_count == 0:
                    rw_mutex.release()

    def writer(wid):
        for _ in range(2):
            with rw_mutex:
                if reading != 0:
                    violations.append(wid)
                old = shared["data"]
                log(f"W{wid} WRITING data {old} -> {old+1}")
                time.sleep(0.03)
                shared["data"] = old + 1

    threads = [threading.Thread(target=reader, args=(i,)) for i in range(1, 4)]
    threads += [threading.Thread(target=writer, args=(i,)) for i in range(1, 3)]
    run_all(threads)
    print(f"Final data={shared['data']} (expected 4), exclusion violations={len(violations)}")

# 3. Dining Philosophers with ordering and waiter
def dining(mode):
    print(f"\\n=== 3. DINING PHILOSOPHERS: {mode.upper()} ===")
    n, meals_per_philosopher = 5, 3
    forks = [threading.Lock() for _ in range(n)]
    waiter = threading.Semaphore(n - 1)
    state = ["T"] * n
    state_lock = threading.Lock()
    meals = [0] * n
    neighbour_clash = []

    def set_state(i, value):
        with state_lock:
            state[i] = value

    def show(i, message):
        with state_lock:
            log(f"P{i} {message:<20} states={' '.join(state)}")

    def philosopher(i):
        left, right = i, (i + 1) % n
        first, second = (min(left, right), max(left, right)) if mode == "ordering" else (left, right)
        for _ in range(meals_per_philosopher):
            time.sleep(random.uniform(0.01, 0.04))
            set_state(i, "H")
            show(i, "is hungry")
            if mode == "waiter":
                waiter.acquire()
            forks[first].acquire()
            forks[second].acquire()
            set_state(i, "E")
            with state_lock:
                if state[(i-1) % n] == "E" or state[(i+1) % n] == "E":
                    neighbour_clash.append(i)
            show(i, f"EATS ({first},{second})")
            meals[i] += 1
            time.sleep(0.02)
            forks[second].release()
            forks[first].release()
            if mode == "waiter":
                waiter.release()
            set_state(i, "T")
            show(i, "put down forks")

    threads = [threading.Thread(target=philosopher, args=(i,)) for i in range(n)]
    run_all(threads)
    print(f"Meals eaten={meals}; neighbour clashes={len(neighbour_clash)}")
    print("All philosophers finished, no deadlock.")

if __name__ == "__main__":
    print("Classical Synchronization Problems - Author: Yash Kumar Gautam")
    producer_consumer()
    readers_writers()
    dining("ordering")
    dining("waiter")
    print("\\nAll programs terminated normally.")
