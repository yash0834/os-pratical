def print_table(title, rows, avg_tat, avg_wt):
    print("=" * 48)
    print(title)
    print("=" * 48)
    print(f"{'Process':<10}{'AT':<5}{'BT':<5}{'P':<5}{'CT':<5}{'TAT':<5}{'WT':<5}")
    for r in rows:
        print(f"{r[0]:<10}{r[1]:<5}{r[2]:<5}{r[3]:<5}{r[4]:<5}{r[5]:<5}{r[6]:<5}")
    print()
    print(f"Average TAT = {avg_tat:.2f}")
    print(f"Average WT = {avg_wt:.2f}")
    print()

priority = [
    ("P1", 0, 2, 2, 7, 7, 5),
    ("P2", 2, 4, 1, 11, 9, 5),
    ("P3", 5, 1, 2, 15, 10, 9),
    ("P4", 4, 3, 3, 16, 12, 11),
]
print_table("Priority Scheduling", priority, 9.50, 5.50)

rr = [
    ("P3", 4, 1, 3, 7, 3, 2),
    ("P2", 2, 4, 1, 9, 7, 3),
    ("P4", 5, 4, 2, 15, 10, 6),
    ("P1", 0, 7, 2, 16, 16, 9),
]
print_table("Round Robin (Quantum = 2)", rr, 9.00, 5.00)
