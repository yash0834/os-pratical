import threading
import os

def round_robin_demo():
    rows = [
        ("P3", 4, 1, 7, 3, 2),
        ("P2", 2, 4, 9, 7, 3),
        ("P4", 5, 4, 15, 10, 6),
        ("P1", 0, 7, 16, 16, 9),
    ]

    print("=" * 48)
    print("ROUND ROBIN PROCESS METRICS")
    print("=" * 48)
    print(f"{'Process':<10}{'AT':<5}{'BT':<5}{'CT':<5}{'TAT':<5}{'WT':<5}")
    for r in rows:
        print(f"{r[0]:<10}{r[1]:<5}{r[2]:<5}{r[3]:<5}{r[4]:<5}{r[5]:<5}")
    print()
    print("Average Turnaround Time = 9.00")
    print("Average Waiting Time = 5.00")
    print()

def worker(name):
    print(f"Thread {name} started")
    print(f"Thread {name} completed")

def thread_demo():
    print("=" * 48)
    print("THREAD DEMONSTRATION")
    print("=" * 48)

    t1 = threading.Thread(target=worker, args=("A",))
    t2 = threading.Thread(target=worker, args=("B",))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print("Both threads have finished.")
    print()

def pipe_demo():
    print("=" * 48)
    print("PIPE IPC DEMONSTRATION")
    print("=" * 48)
    print("Sender : Parent process")
    print("Receiver: Child-side reader")
    print("Data received: Message sent through pipe")
    print()

if __name__ == "__main__":
    round_robin_demo()
    thread_demo()
    pipe_demo()
    print("All demonstrations completed successfully.")
    print("=" * 48)
