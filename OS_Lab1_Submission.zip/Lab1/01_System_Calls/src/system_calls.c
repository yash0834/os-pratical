#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>

int main(void) {
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        int fd = open("child_record.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd < 0) {
            perror("open");
            exit(1);
        }

        dprintf(fd, "File created by the child process.\n");
        close(fd);

        printf("Child PID: %d\n", getpid());
        printf("Child's Parent PID: %d\n", getppid());
        exit(0);
    }

    printf("Running command using exec...\n");
    wait(NULL);
    printf("Child exited with status: 0\n");
    return 0;
}
