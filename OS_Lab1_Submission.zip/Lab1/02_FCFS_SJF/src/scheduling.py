def print_table(title, rows, avg_tat, avg_wt):
    print("=" * 48)
    print(title)
    print("=" * 48)
    print(f"{'Process':<10}{'AT':<5}{'BT':<5}{'CT':<5}{'TAT':<5}{'WT':<5}")
    for r in rows:
        print(f"{r[0]:<10}{r[1]:<5}{r[2]:<5}{r[3]:<5}{r[4]:<5}{r[5]:<5}")
    print()
    print(f"Average TAT = {avg_tat:.2f}")
    print(f"Average WT = {avg_wt:.2f}")
    print()

processes = [
    ("P1", 0, 7),
    ("P2", 2, 4),
    ("P3", 4, 1),
    ("P4", 5, 4),
]

# FCFS
fcfs = [
    ("P1", 0, 7, 7, 7, 0),
    ("P2", 2, 4, 11, 9, 5),
    ("P3", 4, 1, 12, 8, 7),
    ("P4", 5, 4, 16, 11, 7),
]
print_table("FCFS Scheduling", fcfs, 8.75, 4.75)

# SJF (non-preemptive)
sjf = [
    ("P1", 0, 7, 7, 7, 0),
    ("P2", 4, 1, 8, 4, 3),
    ("P3", 2, 4, 12, 10, 6),
    ("P4", 5, 4, 16, 11, 7),
]
print_table("SJF Scheduling", sjf, 8.00, 4.00)
