# Operating Systems Lab 1

Files reconstructed from the provided terminal screenshots.

## Contents
- `Lab1/01_System_Calls/src/system_calls.c`
- `Lab1/01_System_Calls/src/child_record.txt`
- `Lab1/02_FCFS_SJF/src/scheduling.py`
- `Lab1/03_Priority_Round_Robin/src/priority_rr.py`
- `Lab1/04_Metrics_Threads_IPC/src/metrics_threads_ipc.py`

## Run
```bash
gcc system_calls.c -o system_calls
./system_calls

python3 scheduling.py
python3 priority_rr.py
python3 metrics_threads_ipc.py
```
