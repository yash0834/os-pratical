# Operating Systems Lab – Yash Kumar Gautam

Five independent Python projects reconstructed from the uploaded lab PDFs.

## Projects
1. `01_Contiguous_Allocation` – First Fit, Best Fit, Worst Fit, swapping and address translation.
2. `02_Demand_Paging` – FIFO, LRU and Optimal page replacement.
3. `03_Device_Management` – device allocation, shared-device FIFO queue, virtual device and finite buffer.
4. `04_Disk_Scheduling` – FCFS, SSTF, SCAN, C-SCAN and swap-space management.
5. `05_Paging_and_Segmentation` – paging and segmentation address translation.

## Requirements
Python 3.8 or later. No third-party packages are required.

## Run
Open a terminal in the project folder and run the relevant command from that project's README.

Each project is independent and can be pushed to its own GitHub repository, or all five can be pushed together as one repository.
