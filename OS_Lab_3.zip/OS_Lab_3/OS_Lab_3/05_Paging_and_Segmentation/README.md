# Paging and Segmentation

Run: `python3 src/paging_segmentation.py`

Demonstrates paging translation through a page table and segmentation translation through segment base/limit values, including invalid and unmapped address checks.