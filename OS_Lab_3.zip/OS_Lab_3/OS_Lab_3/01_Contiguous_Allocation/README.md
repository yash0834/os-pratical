# Contiguous Allocation, Swapping and Address Translation

Run: `python3 src/contiguous_allocation.py`

Includes First Fit, Best Fit, Worst Fit, a swapping demonstration, and segment-based address translation.