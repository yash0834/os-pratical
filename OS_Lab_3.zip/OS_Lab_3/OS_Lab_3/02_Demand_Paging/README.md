# Demand Paging, Page Replacement and Thrashing

Run: `python3 src/demand_paging.py`

Compares FIFO, LRU, and Optimal page replacement using page hits, page faults, and hit/fault ratios.