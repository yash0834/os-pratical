# Device Management Simulation

Run: `python3 src/device_management.py`

Demonstrates dedicated device allocation, rejection of conflicting requests, a shared-device FIFO queue, virtual device abstraction, finite buffer operations, and device release.