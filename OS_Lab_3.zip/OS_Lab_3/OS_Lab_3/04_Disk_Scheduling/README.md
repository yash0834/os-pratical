# Disk Scheduling and Swap-Space Management

Run: `python3 src/disk_scheduling.py`

Implements FCFS, SSTF, SCAN and C-SCAN disk scheduling, followed by an interactive swap-space allocation/release menu.